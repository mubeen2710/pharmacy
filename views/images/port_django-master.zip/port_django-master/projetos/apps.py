from django.apps import AppConfig


class ProjetosConfig(AppConfig):
    name = 'projetos'
