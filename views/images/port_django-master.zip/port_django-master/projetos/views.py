from django.shortcuts import render

def projeto_view(request):
    return render(request, 'projeto.html', {})